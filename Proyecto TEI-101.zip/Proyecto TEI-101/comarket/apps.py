from django.apps import AppConfig


class ComarketConfig(AppConfig):
    name = 'comarket'
