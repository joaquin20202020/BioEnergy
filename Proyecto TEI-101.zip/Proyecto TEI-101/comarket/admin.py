from django.contrib import admin
from .models import Foro, Mercado

admin.site.register(Foro)
admin.site.register(Mercado)

